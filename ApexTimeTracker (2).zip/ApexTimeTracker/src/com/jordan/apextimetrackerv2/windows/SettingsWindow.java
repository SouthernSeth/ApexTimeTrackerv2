package com.jordan.apextimetrackerv2.windows;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import com.jordan.apextimetrackerv2.util.Strings;

public class SettingsWindow {

	private Properties props;
	private File file;

	public SettingsWindow(final JFrame window) {
		props = new Properties();
		file = new File(Strings.propertiesFilePath);

		props.put("email", "first.last@boeing.com");
		props.put("last_day_of_work_week", "FRIDAY");

		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			try {
				props.load(new FileReader(file));
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		String emailInput = props.getProperty("email");
		String lastDayOfWorkWeek = props.getProperty("last_day_of_work_week");

		Dimension size = new Dimension(250, 150);

		final JFrame email = new JFrame("Settings");
		email.setAlwaysOnTop(true);
		URL iconURL = getClass().getResource("/favicon.png");
		ImageIcon icon = new ImageIcon(iconURL);
		email.setIconImage(icon.getImage());
		email.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		JPanel panel = new JPanel();
		panel.setPreferredSize(size);
		panel.setMaximumSize(size);
		panel.setMinimumSize(size);

		JButton save = new JButton("Save");

		JLabel label_emailField = new JLabel("Email:");
		JLabel label_lastDayOfWorkWeek = new JLabel("Last day of your work week:");

		final JTextField emailField = new JTextField(emailInput, 30);
		JTextField lastDayOfWorkWeekField = new JTextField(lastDayOfWorkWeek, 30);

		panel.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();

		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.gridwidth = 2;
		gbc.insets = new Insets(0,0,0,0);
		//label_emailField.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(label_emailField, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridwidth = 2;
		gbc.insets = new Insets(0,0,10,0);
		panel.add(emailField, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.gridwidth = 2;
		gbc.insets = new Insets(0,0,0,0);
		panel.add(label_lastDayOfWorkWeek, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 3;
		gbc.gridwidth = 2;
		gbc.insets = new Insets(0,0,10,0);
		panel.add(lastDayOfWorkWeekField, gbc);
		
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 4;
		gbc.gridwidth = 2;
		gbc.insets = new Insets(10,0,0,0);
		panel.add(save, gbc);

		email.setContentPane(panel);
		email.pack();
		email.setLocationRelativeTo(null);
		email.setMinimumSize(size);
		email.setResizable(false);

		email.setVisible(true);

		save.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				props.setProperty("email", emailField.getText());
				//props.setProperty("last_day_of_work_week", lastDayOfWorkWeekField.getText());
				try {
					FileOutputStream fos = new FileOutputStream(file);
					props.store(fos, null);
					fos.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				JOptionPane.showMessageDialog(email, "Your settings have been saved!");
				email.dispatchEvent(new WindowEvent(email, WindowEvent.WINDOW_CLOSING));
			}
		});

		email.addWindowListener(new WindowListener() {

			@Override
			public void windowActivated(WindowEvent arg0) {
			}

			@Override
			public void windowClosed(WindowEvent arg0) {
			}

			@Override
			public void windowClosing(WindowEvent arg0) {
				window.setEnabled(true);
			}

			@Override
			public void windowDeactivated(WindowEvent arg0) {
			}

			@Override
			public void windowDeiconified(WindowEvent arg0) {
			}

			@Override
			public void windowIconified(WindowEvent arg0) {
			}

			@Override
			public void windowOpened(WindowEvent arg0) {
			}
		});
	}

}

