package com.jordan.boeingtools;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.LineBorder;

import chrriis.dj.nativeswing.swtimpl.NativeInterface;

public class BoeingTools extends JPanel {

	/**
	 * @author Jordan Wiggins
	 */
	private static final long serialVersionUID = 1L;

	public BoeingTools() {
		super(new GridLayout(3,2,0,0));
		
		for (int i = 0;i<5;i++) {
			JPanel pane = null;
			
			if ( i == 0 ) {
				pane = new WebBrowserContainer("https://nams.web.boeing.com/");
			} else if ( i == 1 ) {
				pane = new WebBrowserContainer("https://mars.web.boeing.com/");
			} else if ( i == 2 ) {
				pane = new WebBrowserContainer("https://insite.web.boeing.com/");
			} else if ( i == 3 ) {
				pane = new WebBrowserContainer("https://netplus.web.boeing.com/");
			} else if ( i == 4 ) {
				pane = new WebBrowserContainer("https://google.com/");
			}
			
			pane.setBorder(new LineBorder(Color.BLACK, 1));
			
			add(pane);
		}
	}

	public static void main(String[] args) {
		NativeInterface.open();
		
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}

		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				JFrame frame = new JFrame("Boeing Tools");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.getContentPane().add(new BoeingTools(), BorderLayout.CENTER);
				frame.setSize(800, 600);
				frame.setLocationByPlatform(true);
				frame.setVisible(true);
			}
		});
		
		NativeInterface.runEventPump();
	}

}
