package com.jordan.boeingtools;

import java.awt.BorderLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import javax.swing.JPanel;

import chrriis.dj.nativeswing.swtimpl.components.JWebBrowser;

public class WebBrowserContainer extends JPanel { 
	
	/**
	 * @author Jordan Wiggins
	 */
	private static final long serialVersionUID = 1L;

	public WebBrowserContainer(String website) {
		super(new BorderLayout());
		
		final JWebBrowser webBrowser = new JWebBrowser();
		webBrowser.navigate(website);
		webBrowser.setBarsVisible(false);
		
		webBrowser.addMouseMotionListener(new MouseMotionListener() {
			@Override
			public void mouseMoved(MouseEvent arg0) {
				
			}
			
			@Override
			public void mouseDragged(MouseEvent arg0) {
				
			}
		});
		
		add(webBrowser, BorderLayout.CENTER);
	}

}
