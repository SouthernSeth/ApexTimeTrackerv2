package com.jordan.pstmonitor;

public class Start {
	
	public static void main(String[] args) {
		new PSTMonitor();
	}

}
