package com.jordan.pstmonitor;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;

public class FindJavaVisitor extends SimpleFileVisitor<Path> {
	
	private ArrayList<File> pstFiles = new ArrayList<File>();
	
	public ArrayList<File> getPSTFiles() {
		
		return pstFiles;
		
	}
	
	public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
		
		if (file.toString().contains(".pst")) {
			if (file.getFileName().toString().endsWith(".pst")) {
				pstFiles.add(file.toAbsolutePath().toFile());
				System.out.println(file.getFileName());
			}
		}
		
		return FileVisitResult.CONTINUE;
		
	}
	
	@Override
	public FileVisitResult visitFileFailed(Path arg0, IOException arg1) throws IOException {
		
		return FileVisitResult.SKIP_SUBTREE;
		
	}

}
