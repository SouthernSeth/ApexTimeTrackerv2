package com.jordan.pstmonitor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Set;

public class PSTMonitor {
	
	public PSTMonitor() {
		Path startingDir = Paths.get("C:\\");
		
		FindJavaVisitor fjv = new FindJavaVisitor();
		
		System.out.println("Scanning for all .pst file on the system now..." + "\n");
		
		try {
			Files.walkFileTree(startingDir, fjv);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("\n" + "Scanning is complete!" + "\n");
		
		System.out.println("Now checking the size of your PST files..." + "\n");
		
		HashMap<String, String> temp = new HashMap<String, String>();
		
		for (int i = 0;i < fjv.getPSTFiles().size();i++) {
			File file = fjv.getPSTFiles().get(i);
			double fileSizeInBytes = file.length();
			double fileSizeInKB = fileSizeInBytes / 1024;
			double fileSizeInMB = fileSizeInKB / 1024;
			if (fileSizeInMB > 500 && fileSizeInMB < 2000) {
				temp.put(file.getName() + " (" + (file.length() / 1024) + "KB) [WARNING]", file.getAbsolutePath());
				System.out.println(file.getName() + " [STATUS=WARNING] - File Size: " + (file.length() / 1024) + "KB");
			} else if (fileSizeInMB >= 2000) {
				temp.put(file.getName() + " (" + (file.length() / 1024) + "KB) [BAD]", file.getAbsolutePath());
				System.out.println(file.getName() + " [STATUS=BAD] - File Size: " + (file.length() / 1024) + "KB");
			} else {
				temp.put(file.getName() + " (" + (file.length() / 1024) + "KB) [OK]", file.getAbsolutePath());
				System.out.println(file.getName() + " [STATUS=OK] - File Size: " + (file.length() / 1024) + "KB");
			}
		}
		
		System.out.println("\n" + "File size check completed!");
		
		System.out.println("\n" + "Outputting to file...");
		
		File file = new File("C:\\PST_MONITOR\\" + System.currentTimeMillis() + "_log.txt");
		file.getParentFile().mkdirs();
	
		try {
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(file));
			
			Set<String> temp2 = temp.keySet();
			
			for (String str : temp2) {
				bw.write(str + " : " + temp.get(str) + "\n");
			}
			
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("\n" + "Saved to C:/PST_MONITOR/" + file.getName());
	}

}
