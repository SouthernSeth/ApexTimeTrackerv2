package com.jordan.apextimetrackerv2.util;

public class Day {
	
	private String week;
	
	private String day;
	
	private String clockInDate;
	private String clockInTime;
	
	private String toLunchDate;
	private String toLunchTime;
	
	private String returnLunchDate;
	private String returnLunchTime;
	
	private String clockOutDate;
	private String clockOutTime;
	
	public Day() {
	}
	
	public String getWeek() {
		return week;
	}
	
	public void setWeek(String week) {
		this.week = week;
	}
	
	public String getDay() {
		return day;
	}
	
	public void setDay(String day) {
		this.day = day;
	}
	
	public String getClockInDate() {
		return clockInDate;
	}
	
	public void setClockInDate(String clockInDate) {
		this.clockInDate = clockInDate;
	}
	
	public String getClockInTime() {
		return clockInTime;
	}
	
	public void setClockInTime(String clockInTime) {
		this.clockInTime = clockInTime;
	}
	
	public String getToLunchDate() {
		return toLunchDate;
	}
	
	public void setToLunchDate(String toLunchDate) {
		this.toLunchDate = toLunchDate;
	}
	
	public String getToLunchTime() {
		return toLunchTime;
	}
	
	public void setToLunchTime(String toLunchTime) {
		this.toLunchTime = toLunchTime;
	}
	
	public String getReturnLunchDate() {
		return returnLunchDate;
	}
	
	public void setReturnLunchDate(String returnLunchDate) {
		this.returnLunchDate = returnLunchDate;
	}
	
	public String getReturnLunchTime() {
		return returnLunchTime;
	}
	
	public void setReturnLunchTime(String returnLunchTime) {
		this.returnLunchTime = returnLunchTime;
	}
	
	public String getClockOutDate() {
		return clockOutDate;
	}
	
	public void setClockOutDate(String clockOutDate) {
		this.clockOutDate = clockOutDate;
	}
	
	public String getClockOutTime() {
		return clockOutTime;
	}
	
	public void setClockOutTime(String clockOutTime) {
		this.clockOutTime = clockOutTime;
	}

}
