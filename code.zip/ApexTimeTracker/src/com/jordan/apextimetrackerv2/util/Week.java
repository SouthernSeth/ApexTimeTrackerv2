package com.jordan.apextimetrackerv2.util;

import java.util.HashMap;

public class Week {
	
	private int id;
	
	private HashMap<String, Day> days;
	
	public Week() {
		days = new HashMap<String, Day>();
	}
	
	public Day getDay(String day) {
		if (days.containsKey(day)) {
			if (days.get(day) != null) {
				return days.get(day);
			}
		}
		return null;
	}
	
	public void setDay(Day day) {
		if (day.getDay() == null) {
			return;
		}
		
		String d = day.getDay();
		days.put(d, day);
	}
	
	public void calculateHours() {
		//DAY, HOURS
		HashMap<String, Double> hours = new HashMap<String, Double>();
		
		//TODO: Calculate hours
	}

}
